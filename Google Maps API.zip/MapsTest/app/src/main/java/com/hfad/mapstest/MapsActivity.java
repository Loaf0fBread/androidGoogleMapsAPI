package com.hfad.mapstest;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private Marker marker;
    private String location;
    private Double lat;
    private Double lng;
    private boolean wasRunning;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        if (savedInstanceState != null) {
            location = savedInstanceState.getString("location");
            lat = savedInstanceState.getDouble("lat");
            lng = savedInstanceState.getDouble("lng");
        }
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if (location != null && lat != null && lng != null) {
            LatLng latLng = new LatLng(lat, lng);
            marker = mMap.addMarker(new MarkerOptions().position(latLng).title(location));
            mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        } else {
            LatLng sydney = new LatLng(-34, 151);
            marker = mMap.addMarker(new MarkerOptions().position(sydney).title("Sydney"));
            mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        }
    }

    public void onMapSearch(View view) {
        EditText locationSearch = findViewById(R.id.search_text);
        location = locationSearch.getText().toString();
        List<Address> addressList = null;

        if (location !=null || !location.equals("")) {
            Geocoder geocoder = new Geocoder(this);
            try {
                addressList = geocoder.getFromLocationName(location, 1);
            } catch (IOException e) {
                e.printStackTrace();
            }

            if (addressList != null && addressList.size() > 0) {
                Address address = addressList.get(0);
                lat = address.getLatitude();
                lng = address.getLongitude();
                LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
                marker.setPosition(latLng);
                marker.setTitle(location);
                mMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
            } else {
                Toast locationNotFound = Toast.makeText(this, "That location does not exist", Toast.LENGTH_SHORT);
                locationNotFound.show();
            }
        }
    }

    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString("location", location);
        savedInstanceState.putDouble("lat", lat);
        savedInstanceState.putDouble("lng", lng);
    }
}
